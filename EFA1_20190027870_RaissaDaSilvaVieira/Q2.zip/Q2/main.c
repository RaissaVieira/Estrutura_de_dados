#include <stdio.h>
#include "conjunto.h"

int main(){

    Conjunto *conj1, *conj2 = criar_conj_vazio();

    printf("%i", size(conj1));
    printf("%i", inserir(*conj1,0,5));
    printf("%i", size(conj1));

    return 0;
}